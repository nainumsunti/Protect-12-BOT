----
# [🐲 รєใғв๏ҭ вұ: ⊰์◉⊱τ∉∂m d®∂ⓖ๏n ❂Ғ w∂®®¡๏®⊰์◉⊱ 🐲](https://line.me/R/ti/p/~mostarz)
PESAN ANE JANGAN DI PERJUAL BELIKAN 
Thank's to:
Allah SWT 

```

